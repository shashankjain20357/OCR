import cv2
import pytesseract
from pdf2image import convert_from_path

def extract_text_from_image(image_path):
    # Load the image using OpenCV
    image = cv2.imread(image_path)

    # Convert the image to grayscale (optional but often improves OCR)
    gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

    # Use PyTesseract to extract text from the image
    extracted_text = pytesseract.image_to_string(gray_image)

    return extracted_text

def extract_text_from_pdf(pdf_path):
    # Convert the PDF pages to images using pdf2image
    pdf_images = convert_from_path(pdf_path)

    extracted_text = ""

    # Process each page as an image and extract text
    for page in pdf_images:
        gray_page = cv2.cvtColor(page, cv2.COLOR_BGR2GRAY)
        page_text = pytesseract.image_to_string(gray_page)
        extracted_text += page_text

    return extracted_text

# Example usage for images
image_path1 = "1.jpg"
image_text1 = extract_text_from_image(image_path1)
print("Text extracted from image 1:")
print(image_text1)

image_path2 = "2.jpg"
image_text2 = extract_text_from_image(image_path2)
print("Text extracted from image 2:")
print(image_text2)

image_path3 = "3.jpg"
image_text3 = extract_text_from_image(image_path3)
print("Text extracted from image 3:")
print(image_text3)

# Example usage for PDFs
pdf_path = "table.pdf"
pdf_text = extract_text_from_pdf(pdf_path)
print("Text extracted from PDF:")
print(pdf_text)

